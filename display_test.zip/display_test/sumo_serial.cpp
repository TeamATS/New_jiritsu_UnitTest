/**
  ******************************************************************************
  * @file           : sumo_serial.cpp
  * @brief          : ロボット相撲用のシリアル通信処理
  ******************************************************************************
  */

// Private includes ----------------------------------------------------------
#include "sumo_serial.h"

// Private typedef -----------------------------------------------------------
// Private define ------------------------------------------------------------
#define TX2 PA2
#define RX2 PA3

// Private macro -------------------------------------------------------------
// Private variables ---------------------------------------------------------
HardwareSerial Serial2(RX2, TX2);

// Private function prototypes -----------------------------------------------
// Private code ---------------------------------------------------------

/**
  * @brief  コンストラクタ
  * @param  u4 ボーレート
  * @retval void
  */
SumoSerial::SumoSerial(u4 baudrate) {
  Serial2.begin(baudrate);
  return;
}

/**
  * @brief  文字列データ受信
  * @param  u1 エコーバックの有無(true/false)
  * @retval String 受信文字列
  */
String SumoSerial::ReadString(u1 enable_echoback) {

  String str = "";

  if (Serial2.available()) {
    str = Serial2.readString();
  }

  if (enable_echoback == true) {
    Serial2.println(str);
  }

  return str;
}
