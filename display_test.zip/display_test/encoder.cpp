/**
  ******************************************************************************
  * @file           : encoder.cpp
  * @brief          : ロボット相撲用のエンコーダ処理
  ******************************************************************************
  */

// Private includes ----------------------------------------------------------
#include "encoder.h"

// Private typedef -----------------------------------------------------------
// Private define ------------------------------------------------------------
#define ENCODER_A PA0
#define ENCODER_B PA1

// Private macro -------------------------------------------------------------
// Private variables ---------------------------------------------------------
volatile s4 Encoder::cnt_ = 0;

// Private function prototypes -----------------------------------------------
// Private code ---------------------------------------------------------

/**
  * @brief  コンストラクタ
  * @param  void
  * @retval void
  */
Encoder::Encoder() {
  pinMode(ENCODER_A, INPUT_PULLUP);
  pinMode(ENCODER_B, INPUT_PULLUP);
  attachInterrupt(ENCODER_A, Update, RISING);

  return;
}

/**
  * @brief  (static)エンコーダ値の更新
  * @param  void
  * @retval void
  */
void Encoder::Update(void) {
  if (digitalRead(ENCODER_B) == LOW) cnt_++;
  else cnt_--;

  return;
}

/**
  * @brief  カウント値の取得
  * @param  void
  * @retval u4 カウント値
  */
s4 Encoder::GetCount(void) {
  return cnt_;
}
