/**
  ******************************************************************************
  * @file           : encoder.h
  * @brief          : ロボット相撲用のエンコーダ処理のヘッダー
  ******************************************************************************
  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __LIB_ENCODER_H
#define __LIB_ENCODER_H

// Includes ------------------------------------------------------------------
#include <Arduino.h>
#include "typedef.h"

// Exported types ------------------------------------------------------------
// Exported constants --------------------------------------------------------
// Exported macro ------------------------------------------------------------
// Exported functions prototypes ---------------------------------------------
// Exported class ------------------------------------------------------------
class Encoder {
  private:
    static volatile s4 cnt_;
    static void Update(void);

  public:
    Encoder();
    s4 GetCount(void);
};

// Exported defines ----------------------------------------------------------

#endif // __LIB_ENCODER_H
