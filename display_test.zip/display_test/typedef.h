#ifndef __LIB_TYPEDEF_h
#define __LIB_TYPEDEF_h

#define U1_ON  1
#define U1_OFF 0

typedef signed char s1;
typedef unsigned char u1;
typedef signed short s2;
typedef unsigned short u2;
typedef signed long s4;
typedef unsigned long u4;

#endif