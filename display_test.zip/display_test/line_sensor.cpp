/**
  ******************************************************************************
  * @file           : line_sensor.cpp
  * @brief          : ロボット相撲用の白線センサ処理
  ******************************************************************************
  */

// Private includes ----------------------------------------------------------
#include "line_sensor.h"

// Private typedef -----------------------------------------------------------
// Private define ------------------------------------------------------------
#define LINE_SENSOR_FR PB6
#define LINE_SENSOR_FL PB7
#define LINE_SENSOR_RR PB8
#define LINE_SENSOR_RL PB9

#define BIT_FR 3
#define BIT_FL 2
#define BIT_RR 1
#define BIT_RL 0

// Private macro -------------------------------------------------------------
// Private variables ---------------------------------------------------------
// Private function prototypes -----------------------------------------------
// Private user code ---------------------------------------------------------

/**
  * @brief  コンストラクタ
  * @param  void
  * @retval void
  */
LineSensor::LineSensor() {
  pinMode(LINE_SENSOR_FR, INPUT_PULLUP);
  pinMode(LINE_SENSOR_FL, INPUT_PULLUP);
  pinMode(LINE_SENSOR_RR, INPUT_PULLUP);
  pinMode(LINE_SENSOR_RL, INPUT_PULLUP);

  return;
}

/**
  * @brief  センサ状態の更新
  * @param  void
  * @retval u1 state
  */
void LineSensor::Update(void) {
  raw_ = (digitalRead(LINE_SENSOR_FR) << BIT_FR) | (digitalRead(LINE_SENSOR_FL) << BIT_FL)
         | (digitalRead(LINE_SENSOR_RR) << BIT_RR) | (digitalRead(LINE_SENSOR_RL) << BIT_RL);

  switch(raw_) {
    case 0b00001100: state_ = LINE_FRONT_BOTH;  break;
    case 0b00001000: state_ = LINE_FRONT_RIGHT; break;
    case 0b00000100: state_ = LINE_FRONT_LEFT;  break;
    case 0b00001010: state_ = LINE_RIGHT_BOTH;  break;
    case 0b00000101: state_ = LINE_LEFT_BOTH;   break;
    case 0b00000011: state_ = LINE_BACK_BOTH;   break;
    case 0b00000010: state_ = LINE_BACK_RIGHT;  break;
    case 0b00000001: state_ = LINE_BACK_LEFT;   break;
    case 0b00001001: state_ = LINE_SLASH;       break;
    case 0b00000110: state_ = LINE_BACKSLASH;   break;
    default:         state_ = LINE_NULL;
  }

  return;
}

/**
  * @brief  感知状態を取得
  * @param  void
  * @retval u1 state_
  */
u1 LineSensor::GetState(void) {
  return state_;
}
