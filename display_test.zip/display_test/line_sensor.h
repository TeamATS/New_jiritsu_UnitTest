/**
  ******************************************************************************
  * @file           : line_sensor.h
  * @brief          : ロボット相撲用の白線センサ処理ヘッダー
  ******************************************************************************
  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __LIB_LINE_SENSOR_H
#define __LIB_LINE_SENSOR_H

// Includes ------------------------------------------------------------------
#include <Arduino.h>
#include "typedef.h"
#include "ring_buffer.h"

// Exported types ------------------------------------------------------------
// Exported constants --------------------------------------------------------
// Exported macro ------------------------------------------------------------
// Exported functions prototypes ---------------------------------------------
// Exported class ------------------------------------------------------------
class LineSensor {
  private:
    u1 raw_;
    u1 state_;
    // RingBuffer buff_(4);

  public:
    LineSensor();
    void Update(void);
    u1 GetRaw(void);
    u1 GetState(void);
};

// Exported defines ----------------------------------------------------------
#define LINE_NULL        0
#define LINE_FRONT_BOTH  1
#define LINE_FRONT_RIGHT 2
#define LINE_FRONT_LEFT  3
#define LINE_RIGHT_BOTH  4
#define LINE_LEFT_BOTH   5
#define LINE_BACK_BOTH   6
#define LINE_BACK_RIGHT  7
#define LINE_BACK_LEFT   8
#define LINE_SLASH       9
#define LINE_BACKSLASH   10
#define LINE_ALL         11

#endif // __LIB_LINE_SENSOR_H
