/**
  ******************************************************************************
  * @file           : tire.cpp
  * @brief          : ロボット相撲用のタイヤ制御
  ******************************************************************************
  */

// Private includes ----------------------------------------------------------
#include "tire.h"

// Private typedef -----------------------------------------------------------
// Private define ------------------------------------------------------------
#define TIRE_R_DIR  PA4
#define TIRE_L_DIR  PA5
#define TIRE_R_PWM  PA6
#define TIRE_L_PWM  PA7
#define HALL_IC     PB10

#define DUTY_MAX 255

// Private macro -------------------------------------------------------------
// Private variables ---------------------------------------------------------
volatile s4 Tire::cnt_ = 0;

// Private function prototypes -----------------------------------------------
// Private code ---------------------------------------------------------

/**
  * @brief  コンストラクタ
  * @param  void
  * @retval void
  */
Tire::Tire() {
  pinMode(TIRE_R_DIR, OUTPUT);
  pinMode(TIRE_L_DIR, OUTPUT);
  analogWriteFrequency(1000);
  analogWrite(TIRE_R_PWM, 0);   // 50% duty
  analogWrite(TIRE_L_PWM, 0);    // 25% duty

  pinMode(HALL_IC, INPUT_PULLUP);
  attachInterrupt(HALL_IC, UpdateCount, RISING);

  return;
}

/**
  * @brief  (static)ホールICカウントの更新
  * @param  void
  * @retval void
  */
void Tire::UpdateCount(void) {
  cnt_++;
  return;
}

/**
  * @brief  ホールICカウントの取得
  * @param  void
  * @retval u4 カウント値
  */
s4 Tire::GetCount(void) {
  return cnt_;
}

/**
  * @brief  駆動状態の設定
  * @param  u1 state 駆動状態
  * @param  u1 percent 出力割合(0～100)
  * @retval void
  */
void Tire::SetDrive(u1 state, u1 percent) {

  u2 duty = DUTY_MAX * percent / 100;

  switch (state) {
    case DRIVE_STOP:
      analogWrite(TIRE_R_PWM, 0);
      analogWrite(TIRE_L_PWM, 0);
      break;
    case DRIVE_FORWORD:
      digitalWrite(TIRE_R_DIR, HIGH);
      digitalWrite(TIRE_L_DIR, HIGH);
      analogWrite(TIRE_R_PWM, duty);
      analogWrite(TIRE_L_PWM, duty);
      break;
    case DRIVE_FORWOED_RIGHT:
      digitalWrite(TIRE_R_DIR, LOW);
      digitalWrite(TIRE_L_DIR, HIGH);
      analogWrite(TIRE_R_PWM, duty);
      analogWrite(TIRE_L_PWM, duty);
      break;
    case DRIVE_FORWOED_RIGHT_PIVOT:
      digitalWrite(TIRE_L_DIR, HIGH);
      analogWrite(TIRE_R_PWM, 0);
      analogWrite(TIRE_L_PWM, duty);
      break;
    case DRIVE_FORWOED_LEFT:
      digitalWrite(TIRE_R_DIR, HIGH);
      digitalWrite(TIRE_L_DIR, LOW);
      analogWrite(TIRE_R_PWM, duty);
      analogWrite(TIRE_L_PWM, duty);
      break;
    case DRIVE_FORWOED_LEFT_PIVOT:
      digitalWrite(TIRE_R_DIR, HIGH);
      analogWrite(TIRE_R_PWM, duty);
      analogWrite(TIRE_L_PWM, 0);
      break;
    case DRIVE_BACK:
      digitalWrite(TIRE_R_DIR, LOW);
      digitalWrite(TIRE_L_DIR, LOW);
      analogWrite(TIRE_R_PWM, duty);
      analogWrite(TIRE_L_PWM, duty);
      break;
    case DRIVE_BACK_RIGHT_PIVOT:
      digitalWrite(TIRE_R_DIR, LOW);
      analogWrite(TIRE_R_PWM, duty);
      analogWrite(TIRE_L_PWM, 0);
      break;
    case DRIVE_BACK_LEFT_PIVOT:
      digitalWrite(TIRE_L_DIR, LOW);
      analogWrite(TIRE_R_PWM, 0);
      analogWrite(TIRE_L_PWM, duty);
      break;
  }

  return;
}
