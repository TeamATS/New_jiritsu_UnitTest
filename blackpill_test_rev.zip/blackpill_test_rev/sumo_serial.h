/**
  ******************************************************************************
  * @file           : sumo_serial.h
  * @brief          : ロボット相撲用のシリアル通信処理のヘッダー
  ******************************************************************************
  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __LIB_SUMO_SERIAL_H
#define __LIB_SUMO_SERIAL_H

// Includes ------------------------------------------------------------------
#include "typedef.h"
#include <Arduino.h>

// Exported types ------------------------------------------------------------
// Exported constants --------------------------------------------------------
// Exported macro ------------------------------------------------------------
// Exported functions prototypes ---------------------------------------------
// Exported class ------------------------------------------------------------
class SumoSerial {
  private:

  public:
    SumoSerial(u4);
    String ReadString(u1);
};

// Exported defines ----------------------------------------------------------

#endif // __LIB_SUMO_SERIAL_H
