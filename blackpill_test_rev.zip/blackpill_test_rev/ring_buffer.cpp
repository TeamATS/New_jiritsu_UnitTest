/**
  ******************************************************************************
  * @file           : ring_buffer.cpp
  * @brief          : リングバッファクラス
  ******************************************************************************
  */

// Private includes ----------------------------------------------------------
#include "ring_buffer.h"

// Private typedef -----------------------------------------------------------
// Private define ------------------------------------------------------------
// Private macro -------------------------------------------------------------
// Private variables ---------------------------------------------------------
// Private function prototypes -----------------------------------------------
// Private user code ---------------------------------------------------------

/**
  * @brief  コンストラクタ
  * @param  u1 バッファサイズ
  * @retval void
  */
RingBuffer::RingBuffer (u1 size) {
  size_ = size;
  buff_ = new u1[size_];
  index_ = 0;
  Init(0);

  return;
}

/**
  * @brief  バッファ初期化
  * @param  u1 初期化値
  * @retval void
  */
void RingBuffer::Init (u1 value) {
  for (u1 i = 0; i < size_; i++){
    buff_[i] = value;
  }
  return;
}

/**
  * @brief  バッファにデータ追加
  * @param  u1 追加データ
  * @retval void
  */
void RingBuffer::Add (u1 value) {
  buff_[index_] = value;

  if (index_ < size_-1) {
    index_++;
  }
  else{
    index_ = 0;
  }

  return;
}

/**
  * @brief  バッファ内のデータ取得
  * @param  u1 取得データの位置(指定値前のデータを取得)
  * @retval u1 指定位置のデータ
  */
u1 RingBuffer::Read (u1 prev) {
  u1 pos;

  if(index_ >= prev) {
    pos = index_ - prev;
  }
  else {
    pos = index_ + size_ - prev;
  }

  return buff_[pos];
}
