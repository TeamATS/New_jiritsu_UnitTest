/**
  ******************************************************************************
  * @file           : ring_buffer.h
  * @brief          : リングバッファクラスヘッダー
  ******************************************************************************
  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __LIB_RING_BUFFER_H
#define __LIB_RING_BUFFER_H

// Includes ------------------------------------------------------------------
#include "typedef.h"

// Exported types ------------------------------------------------------------
// Exported constants --------------------------------------------------------
// Exported macro ------------------------------------------------------------
// Exported functions prototypes ---------------------------------------------
// Exported class ------------------------------------------------------------
class RingBuffer {
  private:
    u1* buff_;
    u1 size_;
    u1 index_;

  public:
    RingBuffer(u1);
    void Init(u1);
    void Add(u1);
    u1 Read(u1);
};

// Exported defines ----------------------------------------------------------

#endif // __LIB_RING_BUFFER_H
