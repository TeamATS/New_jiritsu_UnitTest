/**
  ******************************************************************************
  * @file           : tire.h
  * @brief          : ロボット相撲用のタイヤ制御のヘッダー
  ******************************************************************************
  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __LIB_TIRE_H
#define __LIB_TIRE_H

// Includes ------------------------------------------------------------------
#include <Arduino.h>
#include "typedef.h"

// Exported types ------------------------------------------------------------
// Exported constants --------------------------------------------------------
// Exported macro ------------------------------------------------------------
// Exported functions prototypes ---------------------------------------------
// Exported class ------------------------------------------------------------
class Tire {
  private:
    static volatile s4 cnt_;
    static void UpdateCount(void);

  public:
    Tire();
    void SetDrive(u1, u1);
    s4 GetCount(void);
};

// Exported defines ----------------------------------------------------------
#define DRIVE_STOP                1
#define DRIVE_FORWORD             2
#define DRIVE_FORWOED_RIGHT       3
#define DRIVE_FORWOED_RIGHT_PIVOT 4
#define DRIVE_FORWOED_LEFT        5
#define DRIVE_FORWOED_LEFT_PIVOT  6
#define DRIVE_BACK                7
#define DRIVE_BACK_RIGHT_PIVOT    8
#define DRIVE_BACK_LEFT_PIVOT     9

#endif // __LIB_TIRE_H
